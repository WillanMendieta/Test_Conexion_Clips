   /*******************************************************/
   /*      "C" Language Integrated Production System      */
   /*                                                     */
   /*            CLIPS Version 6.40  06/28/16             */
   /*                                                     */
   /*               USER SETUP HEADER FILE                */
   /*******************************************************/
